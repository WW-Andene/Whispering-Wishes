    // Pseudo-random hash function for deterministic randomness
    const hash = (n) => { const s = Math.sin(n) * 43758.5453; return s - Math.floor(s); };
    const sceneSeed = 52908;

    let lastFrame = 0;
    let cloudCache = null;

    const draw = (t) => {
      animId = requestAnimationFrame(draw);
      if (t - lastFrame < 50) return;
      lastFrame = t;
      const time = t * 0.0005;

      // (all pre-battleground effects removed — only sky + sun in battleground)

      // ===== BATTLEGROUND — ground-plan projected sword field =====
      {
        const W = canvas.width, H = canvas.height;
        const hY = H; // sky covers 100%
        const rng = (i, off) => { const s = Math.sin((i + sceneSeed) * 217.3 + off * 341.7) * 73291.9; return s - Math.floor(s); };

        // --- OPAQUE SKY (lighter, more luminous) ---
        const sk = ctx.createLinearGradient(0, 0, 0, hY);
        sk.addColorStop(0,    'rgb(35,25,55)');
        sk.addColorStop(0.08, 'rgb(55,35,68)');
        sk.addColorStop(0.18, 'rgb(95,55,78)');
        sk.addColorStop(0.30, 'rgb(155,80,82)');
        sk.addColorStop(0.45, 'rgb(210,120,85)');
        sk.addColorStop(0.60, 'rgb(240,160,90)');
        sk.addColorStop(0.75, 'rgb(252,195,100)');
        sk.addColorStop(0.88, 'rgb(255,220,120)');
        sk.addColorStop(1,    'rgb(255,240,160)');
        ctx.fillStyle = sk;
        ctx.fillRect(0, 0, W, hY + 1);

        // === SUN DISC with bright core ===
        const sunX = W * 0.5, sunY = H * 0.3;
        const sunR = H * 0.08;
        const sunHalo = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, sunR * 5);
        sunHalo.addColorStop(0, 'rgba(255,250,200,0.5)');
        sunHalo.addColorStop(0.15, 'rgba(255,230,150,0.3)');
        sunHalo.addColorStop(0.4, 'rgba(255,200,100,0.1)');
        sunHalo.addColorStop(1, 'rgba(255,160,60,0)');
        ctx.fillStyle = sunHalo;
        ctx.fillRect(0, 0, W, hY + 1);
        const sunDisc = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, sunR);
        sunDisc.addColorStop(0, 'rgba(255,255,240,0.95)');
        sunDisc.addColorStop(0.3, 'rgba(255,245,200,0.85)');
        sunDisc.addColorStop(0.7, 'rgba(255,225,140,0.5)');
        sunDisc.addColorStop(1, 'rgba(255,200,100,0)');
        ctx.fillStyle = sunDisc;
        ctx.beginPath(); ctx.arc(sunX, sunY, sunR * 1.5, 0, Math.PI * 2); ctx.fill();

        // === NOISY CLOUD SHAPES with fluid motion ===
        // 2D noise via hash interpolation
        const noise2d = (x, y) => {
          const ix = Math.floor(x), iy = Math.floor(y);
          const fx = x - ix, fy = y - iy;
          const tx = fx * fx * (3 - 2 * fx), ty = fy * fy * (3 - 2 * fy);
          const a = hash(ix * 127.1 + iy * 311.7);
          const b = hash((ix + 1) * 127.1 + iy * 311.7);
          const c = hash(ix * 127.1 + (iy + 1) * 311.7);
          const d = hash((ix + 1) * 127.1 + (iy + 1) * 311.7);
          return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
        };
        // Fractal noise 2D — 4 octaves
        const fnoise2 = (x, y) =>
          noise2d(x, y) * 0.45 + noise2d(x * 2.1, y * 2.1) * 0.28 +
          noise2d(x * 4.3, y * 4.3) * 0.17 + noise2d(x * 8.7, y * 8.7) * 0.1;
        // Curl noise — gives a swirling flow vector from scalar noise
        const curlFlow = (x, y) => {
          const e = 0.01;
          const dndx = (fnoise2(x + e, y) - fnoise2(x - e, y)) / (2 * e);
          const dndy = (fnoise2(x, y + e) - fnoise2(x, y - e)) / (2 * e);
          return [-dndy, dndx]; // perpendicular = curl
        };

        // === CACHED CLOUD SYSTEM ===
        // Build cloud list once, cache shapes to offscreen canvases
        if (!cloudCache || cloudCache.W !== W) {
          cloudCache = { W, clouds: [], frame: 0 };
          const swirlSpeeds = [0.25, 0.18, 0.13, 0.09];
          const swirlOffsets = [0, 1.2, 2.7, 4.1];
          let id = 0;
          for (let sw = 0; sw < 4; sw++) {
            const numCl = 3 + sw;
            for (let cl = 0; cl < numCl; cl++) {
              const s0 = sw * 1000 + cl * 137;
              const dist = sunR * 1.5 + hash(s0 * 0.7) * H * 0.4;
              const angleBase = (cl / numCl) * Math.PI * 2 + swirlOffsets[sw];
              const orbitSpd = swirlSpeeds[sw] / (0.3 + dist / (H * 0.5));
              const bR = (35 + hash(s0) * 55) * 0.65;
              const bStr = 1.8 + hash(s0 + 5) * 1.2;
              const bA = 0.18 + hash(s0 + 10) * 0.12;
              // Parent
              cloudCache.clouds.push({ seed: s0, dist, angleBase, orbitSpd, baseR: bR, stretch: bStr, alpha: bA, sizeClass: 1, angleOff: 0, parent: -1, id: id++ });
              const pIdx = cloudCache.clouds.length - 1;
              // Medium
              const nMed = 1 + Math.floor(hash(s0 + 20) * 2);
              for (let m = 0; m < nMed; m++) {
                const ms = s0 + m * 31 + 200;
                const mAO = (hash(ms) - 0.5) * 1.2;
                const mDO = bR * (0.6 + hash(ms + 1) * 0.8);
                const mR = bR * (0.4 + hash(ms + 2) * 0.3);
                cloudCache.clouds.push({ seed: ms, dist: mDO, angleBase: mAO, orbitSpd: orbitSpd * 1.1, baseR: mR, stretch: 1.3 + hash(ms + 3) * 1.5, alpha: bA * (0.6 + hash(ms + 4) * 0.3), sizeClass: 0.5, angleOff: mAO * 0.3, parent: pIdx, id: id++ });
                const mIdx = cloudCache.clouds.length - 1;
                // Small wisps
                const nSm = Math.floor(hash(ms + 30) * 2);
                for (let s = 0; s < nSm; s++) {
                  const ss = ms + s * 47 + 400;
                  const sAO = (hash(ss) - 0.5) * 2.5;
                  const sDO = mR * (1 + hash(ss + 1) * 2);
                  cloudCache.clouds.push({ seed: ss, dist: sDO, angleBase: sAO, orbitSpd: orbitSpd * 1.3, baseR: mR * (0.2 + hash(ss + 2) * 0.3), stretch: 1.5 + hash(ss + 3) * 2, alpha: bA * 0.5 * (0.3 + hash(ss + 4) * 0.3), sizeClass: 0.15, angleOff: sAO * 0.2, parent: mIdx, id: id++ });
                }
              }
            }
          }
          // Create offscreen canvas + sub-circle lobe data per cloud
          for (const c of cloudCache.clouds) {
            const pad = c.baseR * (c.stretch + 1) * 2;
            const cw = Math.ceil(pad * 2), ch = Math.ceil(c.baseR * 2.5);
            const osc = document.createElement('canvas');
            osc.width = cw; osc.height = ch;
            c.osc = osc; c.oscW = cw; c.oscH = ch;
            // Generate sub-circle lobes
            const numLobes = c.sizeClass > 0.3 ? 7 + Math.floor(hash(c.seed + 99) * 5) : 3 + Math.floor(hash(c.seed + 99) * 3);
            c.lobes = [];
            for (let L = 0; L < numLobes; L++) {
              const angle = hash(c.seed + L * 7.3) * Math.PI * 2;
              const dist = hash(c.seed + L * 13.1 + 50) * c.baseR * 0.6;
              const r = c.baseR * (0.3 + hash(c.seed + L * 5.7 + 100) * 0.5);
              // Drift speed per lobe — slow breathing
              const driftSpd = (hash(c.seed + L * 3.1 + 200) - 0.5) * 0.003;
              const driftPhase = hash(c.seed + L * 9.3 + 300) * Math.PI * 2;
              c.lobes.push({ angle, dist, r, driftSpd, driftPhase });
            }
            // Add 1-3 small trailing wisps (offset further, smaller)
            const numTrail = Math.floor(hash(c.seed + 77) * 3);
            for (let T = 0; T < numTrail; T++) {
              const angle = hash(c.seed + T * 17 + 500) * Math.PI * 2;
              const dist = c.baseR * (0.5 + hash(c.seed + T * 11 + 600) * 0.7);
              const r = c.baseR * (0.1 + hash(c.seed + T * 23 + 700) * 0.15);
              const driftSpd = (hash(c.seed + T * 7 + 800) - 0.5) * 0.005;
              const driftPhase = hash(c.seed + T * 19 + 900) * Math.PI * 2;
              c.lobes.push({ angle, dist, r, driftSpd, driftPhase });
            }
          }
        }

        // Render cloud shape — overlapping circle stamps
        const renderCloudShape = (c, t) => {
          const oc = c.osc.getContext('2d');
          oc.clearRect(0, 0, c.oscW, c.oscH);
          const cx = c.oscW / 2, cy = c.oscH / 2;

          oc.save();
          oc.translate(cx, cy);
          oc.scale(c.stretch, 1);

          const baseAlpha = c.alpha;
          for (const lobe of c.lobes) {
            // Drift: lobe position slowly shifts over time
            const driftAngle = lobe.angle + Math.sin(t * lobe.driftSpd * 50 + lobe.driftPhase) * 0.3;
            const driftDist = lobe.dist + Math.sin(t * lobe.driftSpd * 30 + lobe.driftPhase + 1) * c.baseR * 0.08;
            const lx = Math.cos(driftAngle) * driftDist;
            const ly = Math.sin(driftAngle) * driftDist * 0.45;

            // Outer soft halo
            const grad = oc.createRadialGradient(lx, ly, lobe.r * 0.3, lx, ly, lobe.r);
            grad.addColorStop(0, `rgba(15,8,5,${(baseAlpha * 0.7).toFixed(3)})`);
            grad.addColorStop(0.6, `rgba(13,7,4,${(baseAlpha * 0.35).toFixed(3)})`);
            grad.addColorStop(1, 'rgba(12,6,3,0)');
            oc.fillStyle = grad;
            oc.beginPath();
            oc.arc(lx, ly, lobe.r, 0, Math.PI * 2);
            oc.fill();
          }
          oc.restore();
        };

        // Staggered shape refresh — rebuild 4 clouds per frame
        const refreshPerFrame = 4;
        const cf = cloudCache.frame++;
        for (let i = 0; i < refreshPerFrame; i++) {
          const idx = (cf * refreshPerFrame + i) % cloudCache.clouds.length;
          renderCloudShape(cloudCache.clouds[idx], time);
        }
        // First frame: render all
        if (cf < 2) cloudCache.clouds.forEach(c => renderCloudShape(c, time));

        // Draw cached clouds at orbital positions
        for (const c of cloudCache.clouds) {
          // Compute position
          let cx, cy, tangent;
          if (c.parent === -1) {
            const angle = c.angleBase + time * c.orbitSpd;
            cx = sunX + Math.cos(angle) * c.dist;
            cy = sunY + Math.sin(angle) * c.dist * 0.5;
            tangent = angle + Math.PI / 2;
          } else {
            const p = cloudCache.clouds[c.parent];
            let px, py, pTangent;
            if (p.parent === -1) {
              const pAngle = p.angleBase + time * p.orbitSpd;
              px = sunX + Math.cos(pAngle) * p.dist;
              py = sunY + Math.sin(pAngle) * p.dist * 0.5;
              pTangent = pAngle + Math.PI / 2;
            } else {
              const gp = cloudCache.clouds[p.parent];
              const gpAngle = gp.angleBase + time * gp.orbitSpd;
              const gpx = sunX + Math.cos(gpAngle) * gp.dist;
              const gpy = sunY + Math.sin(gpAngle) * gp.dist * 0.5;
              const pOrbit = gpAngle + p.angleBase + time * p.orbitSpd;
              px = gpx + Math.cos(pOrbit) * p.dist;
              py = gpy + Math.sin(pOrbit) * p.dist * 0.5;
              pTangent = pOrbit + Math.PI / 2;
            }
            const orbit = (c.parent >= 0 ? cloudCache.clouds[c.parent].angleBase + time * cloudCache.clouds[c.parent].orbitSpd : 0) + c.angleBase + time * c.orbitSpd;
            cx = px + Math.cos(orbit) * c.dist;
            cy = py + Math.sin(orbit) * c.dist * 0.5;
            tangent = (pTangent || 0) + c.angleOff;
          }
          ctx.save();
          ctx.translate(cx, cy);
          ctx.rotate(tangent || 0);
          ctx.drawImage(c.osc, -c.oscW / 2, -c.oscH / 2);
          ctx.restore();
        }

        // === FLAT 3D GROUND PLANE (100m × 100m) + 500 SWORDS ===
        const edgeY = H * 0.75; // horizon line — 25% from bottom
        const focal = W * 0.8;

        // Flat ground — no bowl, wy = 0 everywhere
        const camZ = 8;  // camera position in the field
        const camH = 0.7;
        const projX = (wx, wz) => W * 0.5 + wx * focal / (wz - camZ);
        const projY = (wz) => edgeY + camH * focal / (wz - camZ);

        // Ground curve — horizon dips at edges
        const curveStr = H * 0.08;
        const curveY = (sx, sy) => sy - curveStr * Math.pow((sx - W * 0.5) / (W * 0.5), 2);

        // --- Draw curved ground strips ---
        const zNear = camZ + 0.05, zFar = 50, zSlices = 30;
        const xSegs = 12;

        // Dark base fill below horizon
        ctx.fillStyle = 'rgb(18,10,6)';
        ctx.fillRect(0, edgeY, W, H - edgeY);

        for (let i = zSlices - 1; i >= 0; i--) {
          const t0 = i / zSlices, t1 = (i + 1) / zSlices;
          const wz0 = zNear * Math.pow(zFar / zNear, t0);
          const wz1 = zNear * Math.pow(zFar / zNear, t1);

          const depthT = Math.pow(t0, 0.6);
          const r = Math.round(90 - 72 * depthT);
          const g = Math.round(55 - 45 * depthT);
          const b = Math.round(32 - 26 * depthT);
          ctx.fillStyle = `rgb(${r},${g},${b})`;

          ctx.beginPath();
          for (let j = 0; j <= xSegs; j++) {
            const sx = W * j / xSegs;
            const sy = curveY(sx, projY(wz1));
            j === 0 ? ctx.moveTo(sx, sy) : ctx.lineTo(sx, sy);
          }
          for (let j = xSegs; j >= 0; j--) {
            const sx = W * j / xSegs;
            const sy = curveY(sx, projY(wz0));
            ctx.lineTo(sx, sy);
          }
          ctx.closePath();
          ctx.fill();
        }

        // --- SWORDS spread equally on 50m × 50m plane, 2m spacing ---
        const planeSize = 50;
        const baseSpacing = 1;
        const swords = [];
        let swordIdx = 0;

        // Walk the grid with per-sword spacing variation (0.5 to 2)
        for (let bz = 0; bz < planeSize; ) {
          const ihash = (n, off) => { let h = Math.imul(n + off, 2654435761) | 0; h = Math.imul(h ^ (h >>> 16), 0x45d9f3b); h = Math.imul(h ^ (h >>> 13), 0x45d9f3b); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
          const rowSpacingZ = 0.5 + ihash(swordIdx + 7000, sceneSeed) * 1.5;
          for (let bx = -planeSize / 2; bx < planeSize / 2; ) {
            const cellSpacingX = 0.5 + ihash(swordIdx + 8000, sceneSeed) * 1.5;
            const jx = bx + (ihash(swordIdx, sceneSeed + 101) - 0.5) * cellSpacingX * 0.3;
            const jz = bz + (ihash(swordIdx, sceneSeed + 100) - 0.5) * rowSpacingZ * 0.3 + 0.03;
            swordIdx++;
            bx += cellSpacingX;
            if (jz - camZ < 0.02) continue;  // skip swords too close

            // Clearing — based on view angle, not absolute X
            const dz = jz - camZ;
            const pathEnd = 12;
            if (dz > 0.5 && dz < pathEnd) {
              const t = (dz - 0.5) / (pathEnd - 0.5);
              const viewAngle = Math.abs(jx) / dz;
              const innerA = 0.2 * (1 - t * t);   // angle threshold narrows with distance
              const fadeA = 0.08 * (1 - t * t);
              const jitter = (ihash(swordIdx, sceneSeed + 888) - 0.5) * 0.05;
              const effectiveA = viewAngle + jitter;
              if (effectiveA < innerA) continue;
              if (effectiveA < innerA + fadeA) {
                const grad = (effectiveA - innerA) / fadeA;
                if (ihash(swordIdx, sceneSeed + 999) > grad) continue;
              }
            }

            // Project to screen + ground curve
            const scrX = projX(jx, jz);
            const scrY = curveY(scrX, projY(jz));
            if (scrX < -200 || scrX > W + 200 || scrY < -200 || scrY > H + 200) continue;

            const size = 2.8 * focal / (jz - camZ);

            // Curve lean — swords follow the ground curve outward at edges
            const curveLean = -2 * curveStr * (scrX - W * 0.5) / (W * 0.5 * W * 0.5) * 0.3;

            // Random lean + curve lean
            let lh = (swordIdx * 2654435761 + 4829) | 0; lh = Math.imul(lh ^ (lh >>> 16), 0x119de1f3); lh = Math.imul(lh ^ (lh >>> 13), 0x45d9f3b); lh = lh ^ (lh >>> 16);
            const lean = (((lh >>> 0) / 4294967296) * 2 - 1) * (Math.PI * 33.75 / 180) + curveLean;

            // Y-axis rotation — foreshortens width (cos of angle)
            const yAngle = rng(swordIdx, 606) * Math.PI;  // 0-180°
            const yRot = Math.cos(yAngle);

            swords.push({ scrX, scrY, size, lean, yRot, yAngle, wz: jz, wx: jx, shuffle: rng(swordIdx, 200), idx: swordIdx });
          }
          bz += rowSpacingZ;
        }

        // Sort back-to-front
        swords.sort((a, b) => b.wz - a.wz);

        for (const s of swords) {
          // Overall 114.7cm: blade 90.3, guard ~1, grip 18.4, pommel ~5
          const overall = s.size;
          const bladeH = overall * (90.3 / 114.7);
          const mod = bladeH / 8;
          const bladeW = mod * 0.434;                  // 4.9 cm (transform handles rotation)
          const guardH = bladeW / 3;
          const guardW = mod * 1.772;                  // ~20 cm
          const gripW = bladeW * 2 / 3;
          const gripH = overall * (18.4 / 114.7);
          const pomDia = overall * (5.0 / 114.7);
          const pomRx = pomDia / 2;  // transform handles rotation
          const pomRy = pomDia / 2;            // height stays constant

          ctx.save();
          // Flip sword so blade points down into ground, hilt sticks up
          const buried = bladeH * (0.55 + rng(s.idx, 777) * 0.1);
          ctx.beginPath();
          ctx.rect(0, 0, W, s.scrY);
          ctx.clip();
          ctx.translate(s.scrX, s.scrY - buried);
          ctx.scale(1, -1);
          ctx.rotate(-s.lean);
          // 3D Y-axis rotation — skew creates perspective effect
          ctx.transform(Math.abs(s.yRot), 0, Math.sin(s.yAngle) * 0.15, 1, 0, 0);

          const darkSide = 'rgb(10,6,4)';
          const lightSide = 'rgb(30,20,14)';
          // Lighter side faces center (x=0, z=max) — combines position and Y rotation
          const toSunAngle = Math.atan2(-s.wx, 20);  // angle from sword to sun direction
          const leftLight = Math.sin(s.yAngle - toSunAngle) > 0;

          // Blade — split into two halves along Y axis
          const tipEnd = -bladeH + pomDia * 2;
          const ov = 1;
          // Left half
          ctx.fillStyle = leftLight ? lightSide : darkSide;
          ctx.beginPath();
          ctx.moveTo(0, -bladeH);
          ctx.bezierCurveTo(-bladeW * 0.25, -bladeH + pomDia * 0.5,
                            -bladeW * 0.5, tipEnd - pomDia,
                            -bladeW / 2, tipEnd);
          ctx.lineTo(-bladeW / 2, ov);
          ctx.lineTo(0, ov);
          ctx.closePath();
          ctx.fill();
          // Right half
          ctx.fillStyle = leftLight ? darkSide : lightSide;
          ctx.beginPath();
          ctx.moveTo(0, -bladeH);
          ctx.bezierCurveTo(bladeW * 0.25, -bladeH + pomDia * 0.5,
                            bladeW * 0.5, tipEnd - pomDia,
                            bladeW / 2, tipEnd);
          ctx.lineTo(bladeW / 2, ov);
          ctx.lineTo(0, ov);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = darkSide;
          // Guard — varies per sword
          const guardType = ((s.idx * 2654435761 >>> 0) ^ (s.idx * 40503 >>> 0)) % 4;
          ctx.beginPath();
          if (guardType === 1) {
            // Tapered — wider at ends, narrow in middle, spans 0 to guardH
            const endH = guardH * 2;
            ctx.moveTo(-guardW / 2, guardH / 2 - endH / 2);
            ctx.lineTo(-guardW / 2, guardH / 2 + endH / 2);
            ctx.bezierCurveTo(-guardW / 4, guardH, guardW / 4, guardH, guardW / 2, guardH / 2 + endH / 2);
            ctx.lineTo(guardW / 2, guardH / 2 - endH / 2);
            ctx.bezierCurveTo(guardW / 4, 0, -guardW / 4, 0, -guardW / 2, guardH / 2 - endH / 2);
            ctx.closePath();
          } else if (guardType === 2) {
            // Curved down — flat ends, spans 0 to guardH
            ctx.moveTo(-guardW / 2, 0);
            ctx.lineTo(-guardW / 2, guardH);
            ctx.quadraticCurveTo(0, guardH * 3, guardW / 2, guardH);
            ctx.lineTo(guardW / 2, 0);
            ctx.quadraticCurveTo(0, guardH * 2, -guardW / 2, 0);
            ctx.closePath();
          } else if (guardType === 3) {
            // Three segmented — center block + two end blocks
            const segW = guardW * 0.12;
            const segH = guardH * 1.5;
            ctx.rect(-guardW / 2 - segW / 2, -segH / 2 + guardH / 2, segW, segH);
            ctx.rect(-segW / 2, 0, segW, guardH);
            ctx.rect(guardW / 2 - segW / 2, -segH / 2 + guardH / 2, segW, segH);
            ctx.rect(-guardW / 2, 0, guardW, guardH);
          } else {
            // Straight (default)
            ctx.rect(-guardW / 2, 0, guardW, guardH);
          }
          ctx.fill();
          // Grip — straight rectangle (overlap into guard and pommel)
          const gripBot = guardH + gripH;
          ctx.fillRect(-gripW / 2, guardH - ov, gripW, gripH + ov * 2);
          // Pommel — sits directly on grip
          let ph = (s.idx * 2246822519 + 400) | 0; ph = Math.imul(ph ^ (ph >>> 16), 0x45d9f3b); ph = Math.imul(ph ^ (ph >>> 13), 0x45d9f3b); ph = ph ^ (ph >>> 16);
          const pommelType = (ph >>> 0) % 2;
          ctx.beginPath();
          if (pommelType === 1) {
            // Circle
            ctx.arc(0, gripBot + pomRy, pomRy, 0, Math.PI * 2);
          } else {
            // Fan — narrow flat bottom at grip, inward curved sides, wide curved top
            const fanBotW = gripW * 0.6;    // half-width at bottom (narrow, at grip)
            const fanTopW = bladeW * 0.8;   // half-width at top
            const fanH = pomDia;
            ctx.moveTo(-fanBotW, gripBot);  // flat bottom-left (grip connection)
            ctx.lineTo(fanBotW, gripBot);   // flat bottom-right
            // Right side — curves inward
            ctx.quadraticCurveTo(fanBotW * 0.5, gripBot + fanH * 0.5,
                                  fanTopW, gripBot + fanH);
            // Top — curves outward (away from grip)
            ctx.quadraticCurveTo(0, gripBot + fanH + fanH * 0.5,
                                  -fanTopW, gripBot + fanH);
            // Left side — curves inward
            ctx.quadraticCurveTo(-fanBotW * 0.5, gripBot + fanH * 0.5,
                                  -fanBotW, gripBot);
            ctx.closePath();
          }
          ctx.fill();

          ctx.restore();
        }

      } // end BATTLEGROUND block
    };

    animId = requestAnimationFrame(draw);
