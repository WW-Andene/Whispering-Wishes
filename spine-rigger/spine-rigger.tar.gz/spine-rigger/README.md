# Spine Rigger

Sprite → Skeleton → Spine JSON

Upload a character sprite, auto-detect or manually place bones, export Spine-compatible skeleton JSON.

## Stack
- Next.js 14 (App Router)
- MediaPipe Pose Landmarker (in-browser, no API key)
- Canvas 2D bone editor
- Spine JSON 4.1 export

## Deploy

```bash
# From Termux
git init spine-rigger && cd spine-rigger
# copy files or clone
npm install
```

Push to GitHub, connect to Vercel. No env vars needed.

## Usage

1. Upload sprite (PNG with transparent background recommended)
2. Bones appear at default positions
3. Tap **Auto-Detect** to run MediaPipe pose estimation
4. **Drag bones** to correct positions
5. Tap **Export Spine JSON** to download skeleton.json
6. Import into Spine Editor

## Limitations

- MediaPipe is trained on real humans — accuracy varies on anime/stylized characters
- Manual correction is expected and normal
- Spine JSON includes skeleton only (no mesh/skin attachments)
- Single-pose detection (front-facing works best)
